package jp.example.elesiteyurakucho;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String URL = "https://www.elesite-next.com/train_location";
    private static final int MAX_ATTEMPTS = 24;

    private TextView trainNumberText, formationText, statusText;
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int attempt = 0;
    private boolean finished = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(jp.example.elesiteyurakucho.R.layout.activity_main);

        trainNumberText = findViewById(R.id.trainNumberText);
        formationText = findViewById(R.id.formationText);
        statusText = findViewById(R.id.statusText);
        Button retryButton = findViewById(R.id.retryButton);
        webView = findViewById(R.id.webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString() + " ElesiteYurakuchoPrototype/0.1");

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                statusText.setText("えれサイトを解析中…");
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) showError("ページを読み込めませんでした");
            }
        });

        retryButton.setOnClickListener(v -> startFetch());
        startFetch();
    }

    private void startFetch() {
        finished = false;
        attempt = 0;
        trainNumberText.setText("取得中…");
        formationText.setText("取得中…");
        trainNumberText.setTextColor(Color.WHITE);
        formationText.setTextColor(Color.WHITE);
        statusText.setText("えれサイトへ接続中…");
        webView.loadUrl(URL);
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::automationTick, 1800);
    }

    private void automationTick() {
        if (finished) return;
        attempt++;
        if (attempt > MAX_ATTEMPTS) {
            showError("有楽町線の21:07列車を特定できませんでした");
            return;
        }

        webView.evaluateJavascript(AUTOMATION_JS, null);
        handler.postDelayed(this::automationTick, 1300);
    }

    private void showError(String detail) {
        if (finished) return;
        finished = true;
        trainNumberText.setText("ERROR");
        formationText.setText("ERROR");
        trainNumberText.setTextColor(Color.rgb(255, 95, 95));
        formationText.setTextColor(Color.rgb(255, 95, 95));
        statusText.setText("運用情報取得エラー\n" + detail);
    }

    private class Bridge {
        @JavascriptInterface
        public void success(String json) {
            runOnUiThread(() -> {
                if (finished) return;
                try {
                    JSONObject obj = new JSONObject(json);
                    String train = obj.optString("trainNumber", "").trim();
                    String formation = obj.optString("formation", "").trim();
                    if (train.isEmpty() || formation.isEmpty()) {
                        showError("列車番号または充当編成がページ上で確認できませんでした");
                        return;
                    }
                    finished = true;
                    trainNumberText.setText(train);
                    formationText.setText(formation.endsWith("F") ? formation : formation + "F");
                    statusText.setText("えれサイトから取得済み");
                } catch (Exception e) {
                    showError("取得結果の解析に失敗しました");
                }
            });
        }

        @JavascriptInterface
        public void fail(String reason) {
            // JS側は途中段階でもfailを返し得るため、最終失敗はattempt上限で判定する。
        }
    }

    /*
     * えれサイトは路線選択をブラウザ側で保持するため、WebView上でUIを順に操作する。
     * 21:07に時刻を合わせた後、小竹向原の表示位置に最も近い列番/編成候補を採用する。
     * 取得できない場合は値を捏造せず ERROR にする。
     */
    private static final String AUTOMATION_JS = """
(() => {
  try {
    const txt = (e) => (e && (e.innerText || e.textContent) || '').replace(/\\s+/g,' ').trim();
    const visible = (e) => {
      if (!e) return false;
      const r=e.getBoundingClientRect(), s=getComputedStyle(e);
      return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden';
    };
    const all=[...document.querySelectorAll('button,a,[role=button],div,span,label')].filter(visible);
    const clickText=(needle) => {
      const exact=all.find(e => txt(e)===needle);
      const partial=all.find(e => txt(e).includes(needle) && txt(e).length<40);
      const el=exact||partial;
      if(el){ el.click(); return true; }
      return false;
    };
    const body=txt(document.body);

    // 路線が未選択なら、利用可能な階層を内側から順に押す。
    if(!body.includes('有楽町線') || !body.includes('小竹向原')) {
      if(clickText('有楽町線')) return;
      if(clickText('東京メトロ')) return;
      if(clickText('地下鉄')) return;
      if(clickText('関東')) return;
      if(clickText('路線選択')) return;
      AndroidBridge.fail('route');
      return;
    }

    // 21:07へ移動。時刻入力UIがあれば直接設定する。
    const timeInputs=[...document.querySelectorAll('input[type=time]')].filter(visible);
    if(timeInputs.length){
      const i=timeInputs[0];
      if(i.value!=='21:07'){
        i.value='21:07';
        i.dispatchEvent(new Event('input',{bubbles:true}));
        i.dispatchEvent(new Event('change',{bubbles:true}));
        clickText('決定');
        return;
      }
    } else if(clickText('時刻を選ぶ')) {
      return;
    }

    // 列番を画面に出せるUIがあれば有効化。
    const numberToggle=all.find(e => txt(e)==='列番表示');
    if(numberToggle && numberToggle.getAttribute('aria-checked')==='false'){
      numberToggle.click(); return;
    }

    // 小竹向原ラベルの位置を基準に、近い列車情報を探す。
    const stationEls=[...document.querySelectorAll('*')].filter(e => visible(e) && txt(e)==='小竹向原');
    if(!stationEls.length){ AndroidBridge.fail('station'); return; }
    const sr=stationEls[0].getBoundingClientRect();
    const sx=sr.left+sr.width/2, sy=sr.top+sr.height/2;

    const nodes=[...document.querySelectorAll('*')].filter(visible).map(e=>{
      const t=txt(e); if(!t || t.length>80) return null;
      const r=e.getBoundingClientRect();
      const x=r.left+r.width/2, y=r.top+r.height/2;
      return {e,t,d:Math.hypot(x-sx,y-sy)};
    }).filter(Boolean);

    // メトロ系列番の代表的な表記（例 83S / 2183S / 21S 等）を広めに許容。
    const trainRx=/^(?:\\d{1,4}[A-Z]|[A-Z]\\d{1,4}[A-Z]?)$/;
    // 編成はサイト側がF無しで表示する場合も考慮。東京メトロ17000系を優先。
    const formRx=/^(?:17\\d{3}F?|10\\d{3}F?|[0-9]{4,5}F)$/;

    const trainC=nodes.filter(n=>trainRx.test(n.t)).sort((a,b)=>a.d-b.d);
    const formC=nodes.filter(n=>formRx.test(n.t)).sort((a,b)=>a.d-b.d);

    // 21:07/新木場の文字が近傍にある候補を優先する。
    const contextScore=(n)=>{
      let score=n.d;
      const r=n.e.getBoundingClientRect();
      for(const q of nodes){
        if(q.t.includes('21:07')) score -= Math.max(0,500-Math.abs(q.d-n.d))*0.15;
        if(q.t.includes('新木場')) score -= Math.max(0,500-Math.abs(q.d-n.d))*0.10;
      }
      return score;
    };
    trainC.sort((a,b)=>contextScore(a)-contextScore(b));
    formC.sort((a,b)=>contextScore(a)-contextScore(b));

    const train=trainC[0]?.t || '';
    let formation=formC[0]?.t || '';
    if(formation && !formation.endsWith('F')) formation += 'F';

    if(train && formation){
      AndroidBridge.success(JSON.stringify({trainNumber:train, formation}));
    } else {
      AndroidBridge.fail('not_found');
    }
  } catch(e) {
    AndroidBridge.fail('exception:'+e.message);
  }
})();
""";
}
