# 有楽町線 21:07 運用取得テスト

Android向けの最小試作です。

## 動作
- `https://www.elesite-next.com/train_location` を非表示WebViewで開く
- えれサイトの路線選択UIから「関東 → 地下鉄 → 東京メトロ → 有楽町線」を自動探索
- 表示時刻を 21:07 に設定
- 小竹向原付近の列車情報から、列車番号と充当編成をDOM上で探索
- **列車番号と編成の両方が取れた場合だけ表示**
- 取得失敗・HTML構造変更・路線選択失敗時は `運用情報取得エラー / ERROR` と表示

## 重要
えれサイトは動的Web UIのため、サイト側のDOM構造や表示方式が変わると抽出ロジックの調整が必要です。
この試作は値を推測・捏造しません。

## ビルド
Android Studioでこのフォルダを開き、Gradle Sync後に実機へRunしてください。
minSdk 26 / targetSdk 35。

## スマホだけでAPKを作る方法
このリポジトリをGitHubへアップロードすると、`.github/workflows/build-apk.yml` が自動でdebug APKをビルドします。

1. GitHubのActionsを開く
2. `Build Android APK` を開く
3. `Run workflow` を実行（push時にも自動実行）
4. 完了後、Artifacts の `elesite-yurakucho-debug-apk` をダウンロード
5. ZIP内の `app-debug.apk` をAndroidへインストール
